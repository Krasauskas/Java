/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment1part1;

/**
 *
 * @author childm
 */
public interface ArrayProcessor {
    String getName();
    String getDescription();
    double[] execute( double[] array);
} 

